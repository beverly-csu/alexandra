#include<iostream>
#include<filesystem>
#include<fstream>
#include<string>
#include<vector>

using namespace std;
using namespace filesystem;

int main()
{
    setlocale(0, "ru");

    vector <string> Filename;
    vector <int> Filesize;
    int size_file_name = 0;
    path way = "C:\\Users\\DNS\\���������\\�� 2 ����\\Task_3";
    error_code ec;

    for (auto& p : directory_iterator(way))
    {
        way /= p.path();

        Filename.push_back(way.string());
        Filesize.push_back(file_size(way, ec));
        size_file_name++;
        way.remove_filename();
    }

    for (int i = 0; i < size_file_name; i++)
    {
        cout << Filename[i] << " | size: " << Filesize[i] / 1024 << " ��" << endl;
    }

    int rezult_size = 0;
    for (int i = 0; i < size_file_name; i++)
    {
        rezult_size += Filesize[i] / 1024;
        if (rezult_size >= 3000)
        {
            create_directories(way);
            rezult_size = 0;
        }
    }

    return 0;
}